# AI-Powered Food Detection and Recipe Chatbot System (Group1C-FDRCS)

[![University](https://img.shields.io/badge/University-UENR-blue.svg)](https://uenr.edu.gh/)
[![Degree](https://img.shields.io/badge/Degree-B.Sc._Information_Technology-green.svg)](#)
[![Python](https://img.shields.io/badge/Python-3.11+-3776AB.svg?logo=python&logoColor=white)](https://www.python.org/)
[![Django](https://img.shields.io/badge/Django-5.2+-092E20.svg?logo=django&logoColor=white)](https://www.djangoproject.com/)
[![React Native](https://img.shields.io/badge/React_Native-Expo-61DAFB.svg?logo=react&logoColor=black)](https://reactnative.dev/)
[![AI](https://img.shields.io/badge/AI-Google_Gemini-8E75B2.svg?logo=google-gemini&logoColor=white)](https://ai.google.dev/)
[![Docker](https://img.shields.io/badge/Docker-Ready-2496ED.svg?logo=docker&logoColor=white)](https://www.docker.com/)

An intelligent mobile and server-side platform that bridges the gap in automated food recognition for regional African (specifically Ghanaian) and international cuisines. The system integrates computer vision for image-based food classification, Google Gemini Generative AI for dynamic culinary instruction through conversational assistant **Chef Latifa**, and the YouTube Data API for curated cooking tutorial video retrieval.

---

## 🎓 Academic Information & Project Group

- **Institution:** University of Energy and Natural Resources (UENR), Sunyani
- **Department:** Department of Information Technology and Decision Sciences
- **Programme:** Bachelor of Science in Information Technology
- **Project Title:** AI-POWERED FOOD DETECTION AND RECIPE CHATBOT SYSTEM
- **Repository / Group ID:** Group 1C (`Group1C-FDRCS`)
- **Academic Year:** August, 2026
- **Project Supervisor:** Dr. Anokye Acheampong Amponsah

### Group 1C Members
| # | Full Name | Program | Role / Contribution |
|---|-----------|---------|---------------------|
| 1 | **Ahmed Bayugo Latifatu** | B.Sc. Information Technology | Project Lead & Student Contributor |
| 2 | **Oteng Francis Kofi** | B.Sc. Information Technology | Group Member & Student Contributor |
| 3 | **Boham Johnson** | B.Sc. Information Technology | Group Member & Student Contributor |
| 4 | **Bugbila Peter Dorzie** | B.Sc. Information Technology | Group Member & Student Contributor |
| 5 | **Awuye K. Philip** | B.Sc. Information Technology | Group Member & Student Contributor |

---

## 📌 Executive Summary & Abstract

Food recognition and recipe recommendation systems have rapidly matured with advancements in Computer Vision and Deep Learning. However, mainstream benchmark datasets (such as Food-101) are heavily skewed towards Western and Asian cuisines, resulting in significant classification failure when applied to African dishes.

The **FoodLens (Group1C-FDRCS)** platform addresses this challenge using a Design Science Research methodology:
1. **Transfer Learning Pipeline:** Combines the benchmark Food-101 dataset (101,000 images across 101 classes) supplemented with a curated, locally sourced dataset of indigenous Ghanaian dishes (e.g., *Jollof Rice, Banku, Fufu, Waakye, Kelewele, Kenkey, Aprapransa, Emo Tuo, Tuo Zaafi, Akple, Ampesi, Red Red*).
2. **Dual-Stage Classification:** Uses a lightweight Convolutional Neural Network (CNN / MobileNetV2 / Swin) optimized for server deployment, combined with an automated Google Gemini Vision fallback for edge cases and low-confidence inputs.
3. **Conversational Culinary Assistant:** Bridges the knowledge-delivery gap through **Chef Latifa**, an AI assistant powered by Google Gemini that generates contextual recipes, step-by-step preparation procedures, dietary/allergen alerts, and manages a synchronized shopping list.
4. **Multimodal Media Integration:** Automatically fetches top-ranked video demonstrations via YouTube Data API v3 and RapidAPI with server-side caching.

---

## 🚀 Key Features

- 📸 **Camera & Image Upload Detection:** Capture food directly through the device camera or select high-resolution images from the photo gallery.
- 🍲 **Culturally Inclusive Classification:** Recognizes both global staples and popular Ghanaian dishes with high precision and confidence metrics.
- 🥗 **Instant Recipe & Nutritional Facts:** Generates estimated calories, carbohydrates, protein content, allergen notices, and regional origins.
- 👩‍🍳 **AI Chatbot ("Chef Latifa"):** Free-form conversational assistant ready to answer culinary questions, suggest ingredient substitutes, guide cooking steps, and assist with dietary preferences.
- 🛒 **Smart Grocery / Shopping List:** Add recipe ingredients directly to an interactive checklist with one tap or via natural language commands to Chef Latifa; features guest local storage and authenticated user sync.
- 📺 **Curated YouTube Cooking Tutorials:** Retrieves top 3 step-by-step cooking videos for any recognized dish with thumbnail, video title, and direct link playback.
- 🔒 **Secure User Authentication:** JSON Web Token (JWT) based login, registration, and automatic token refresh to ensure user privacy and stateless API scalability.
- 📜 **Detection History Log:** Allows registered users to revisit past scans with uploaded dish photos, predictions, and timestamps.
- 🌓 **Theming & Accessibility:** Built-in Light and Dark themes, smooth animations, and responsive layouts across iOS and Android.

---

## 🏛️ System Architecture

The project employs a modern, decoupled client-server architecture:

```mermaid
flowchart TD
    subgraph Client ["Mobile Client (React Native / Expo)"]
        UI[User Interface & Camera]
        State[Auth & Theme Context]
        LocalStore[Local Storage / Guest Cart]
    end

    subgraph Backend ["Django REST API Server"]
        API[API Endpoints & Routers]
        Auth[JWT Authentication Service]
        Cache[Video Search Cache]
        DB[(SQLite / PostgreSQL Database)]
    end

    subgraph ML_AI ["AI & Machine Learning Engine"]
        CNN[Local CNN Classifier]
        Gemini[Google Gemini Generative AI]
        YouTube[YouTube Data API v3]
    end

    UI -->|Image Upload / Form Data| API
    UI -->|JWT Auth & Shopping Requests| API
    API --> Auth
    API --> DB
    API -->|1. Run Classification| CNN
    API -->|2. Fallback / Recipe Generation| Gemini
    API -->|3. Query Videos / Cache Hit| Cache
    Cache -.->|Cache Miss| YouTube
    Gemini -->|Structured JSON Recipe / Chat| API
    API -->|JSON Response| UI
```

### Use Case Overview
The system supports primary user interactions including user authentication, food scanning, viewing detection results, interacting with Chef Latifa, managing shopping lists, and watching video tutorials.

![Use Case Diagram](Usecase.png)

---

## 📁 Repository Structure

```text
Group1C-FDRCS/
├── backend/                        # Django REST API Backend
│   ├── api/                        # Core application
│   │   ├── migrations/             # Database schema migrations
│   │   ├── admin.py                # Django admin configuration
│   │   ├── apps.py                 # App initialization
│   │   ├── ml_service.py           # Food detection & Gemini AI orchestrator
│   │   ├── models.py               # Database models (ShoppingItem, History, Cache)
│   │   ├── serializers.py          # DRF serializers
│   │   ├── urls.py                 # REST API route endpoints
│   │   └── views.py                # View controllers and business logic
│   ├── backend/                    # Project settings and WSGI/ASGI configuration
│   │   ├── settings.py             # Environment-aware Django settings
│   │   ├── urls.py                 # Root URL routing
│   │   └── wsgi.py                 # WSGI entrypoint
│   ├── .env.example                # Backend environment configuration template
│   ├── Dockerfile                  # Container definition for Python backend
│   ├── entrypoint.sh               # Migration runner and startup script
│   ├── manage.py                   # Django CLI utility
│   └── requirements.txt            # Python dependencies
├── frontend/                       # React Native Mobile App (Expo)
│   ├── app/                        # Expo Router screen navigation
│   │   ├── _layout.jsx             # Root layout with navigation & headers
│   │   ├── index.jsx               # Home screen / Dashboard
│   │   ├── auth.jsx                # Login and registration screen
│   │   ├── recipe.jsx              # Recipe details & nutritional pills
│   │   ├── chat.jsx                # Chef Latifa conversational AI screen
│   │   ├── shopping.jsx            # Interactive grocery list screen
│   │   ├── videos.jsx              # YouTube video tutorial screen
│   │   └── settings.jsx            # User profile and theme toggle screen
│   ├── assets/                     # App icons, splash screens, and logos
│   ├── context/                    # ThemeContext and state providers
│   ├── app.json                    # Expo application configuration
│   ├── config.js                   # Centralized API base URL config
│   ├── Dockerfile                  # Frontend container definition
│   ├── eas.json                    # Expo Application Services build config
│   └── package.json                # Node.js dependencies & scripts
├── docker-compose.yml              # Multi-container Docker orchestration
├── Usecase.png                     # System use case diagram
├── .gitignore                      # Git exclusion rules
└── README.md                       # Comprehensive documentation
```

---

## 🛠️ Technology Stack

| Domain | Technology / Library | Purpose |
|--------|----------------------|---------|
| **Mobile Frontend** | React Native (Expo SDK 54), Expo Router | Cross-platform iOS & Android user interface |
| **Styling & Icons** | React Native StyleSheet, Lucide Icons | Clean modern design system with responsive layouts |
| **Backend Framework** | Django 5.2, Django REST Framework | Scalable RESTful API, ORM, and request lifecycle |
| **Authentication** | SimpleJWT (`djangorestframework_simplejwt`) | Secure token-based authentication |
| **Computer Vision** | PyTorch, MobileNetV2 / Swin, Pillow | Deep learning food classification on Food-101 + local dishes |
| **Generative AI** | Google Gemini (`google-generativeai`) | Contextual recipe generation and conversational assistant |
| **Video Integration** | YouTube Data API v3 & RapidAPI | Streaming video tutorials with server-side caching |
| **Database** | SQLite (Development) / PostgreSQL-ready | Relational data persistence |
| **DevOps / Containers**| Docker, Docker Compose | Reproducible development and deployment environments |

---

## ⚙️ Environment Variables Setup

Before running the backend, create a `.env` file in the `backend/` directory:

```bash
cp backend/.env.example backend/.env
```

Configure the following variables in `backend/.env`:

```ini
# Django Configuration
SECRET_KEY=your-django-secret-key-here
DEBUG=True

# Google Gemini AI Keys (at least one key is required)
GEMINI_API_KEY=your_primary_gemini_api_key
GEMINI_API_KEY_1=your_secondary_gemini_key_optional
GEMINI_API_KEY_2=your_tertiary_gemini_key_optional

# RapidAPI Keys (used for video search & rapid AI endpoints)
RAPIDAPI_KEY=your_primary_rapidapi_key
RAPIDAPI_KEY_1=
RAPIDAPI_KEY_2=

# Google YouTube Data API v3 (Optional if RapidAPI key is set)
YOUTUBE_API_KEY=your_google_youtube_api_key

# Hugging Face Access Token (Optional)
HF_TOKEN=your_huggingface_token
```

---

## 🚀 Getting Started & Installation

### Option 1: Quickstart with Docker Compose (Recommended)

Ensure you have [Docker Desktop](https://www.docker.com/) installed and running.

1. Clone the repository:
   ```bash
   git clone https://github.com/AhmedBayugoLatifa/Group1C-FDRCS.git
   cd Group1C-FDRCS
   ```

2. Build and run both the backend and frontend containers:
   ```bash
   docker compose up --build
   ```

- **Backend API:** Available at `http://localhost:8000`
- **Frontend Expo Server:** Available at `http://localhost:8081`

---

### Option 2: Manual Local Development Setup

#### 1. Backend Setup (Django API)

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create and activate a Python virtual environment:
   ```bash
   # Windows
   python -m venv .venv
   .\.venv\Scripts\activate

   # macOS / Linux
   python3 -m venv .venv
   source .venv/bin/activate
   ```

3. Install required Python packages:
   ```bash
   pip install -r requirements.txt
   ```

4. Apply database migrations:
   ```bash
   python manage.py migrate
   ```

5. Start the development server:
   ```bash
   python manage.py runserver 0.0.0.0:8000
   ```

#### 2. Frontend Setup (React Native Expo)

1. Open a new terminal and navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install Node.js dependencies:
   ```bash
   npm install
   ```

3. Configure Backend Host:
   Open `frontend/config.js` and set `API_BASE_URL` to your machine's local IP address (e.g. `http://192.168.1.100:8000/api`) so mobile devices and emulators can reach the backend.

4. Start the Expo development server:
   ```bash
   npx expo start
   ```

   - Press `a` to run on an connected **Android device / emulator**.
   - Press `i` to run on an **iOS simulator**.
   - Press `w` to run in a **web browser**.
   - Scan the terminal QR code using the **Expo Go** app on your physical mobile phone.

---

## 📡 REST API Reference

| Method | Endpoint | Auth Required | Description |
|--------|----------|---------------|-------------|
| `POST` | `/api/register/` | No | Register a new user account |
| `POST` | `/api/login/` | No | Authenticate and obtain JWT access & refresh tokens |
| `POST` | `/api/token/refresh/` | No | Refresh expired JWT access token |
| `PATCH`| `/api/profile/update/` | Yes | Update user username, email, or password |
| `POST` | `/api/detect/` | Optional | Upload image multipart data for classification and recipe extraction |
| `GET`  | `/api/history/` | Yes | Retrieve scan and detection history for authenticated user |
| `DELETE`| `/api/delete-history/<id>/` | Yes | Delete a specific detection history item |
| `POST` | `/api/chat/` | Yes | Send culinary prompt to conversational assistant Chef Latifa |
| `GET`  | `/api/videos/search/?q=<query>` | Optional | Search YouTube video tutorials for a dish (cached) |
| `GET`  | `/api/shopping/` | Yes | Retrieve user's grocery items |
| `POST` | `/api/shopping/` | Yes | Add single item to shopping list |
| `POST` | `/api/shopping/bulk/` | Yes | Bulk add recipe ingredients to shopping list |
| `PATCH`| `/api/shopping/<id>/` | Yes | Toggle or update shopping item status |
| `DELETE`| `/api/shopping/?id=<id>` | Yes | Remove item from shopping list |

---

## 📖 Key Academic Citations

1. **Bossard, L., Guillaumin, M., & Van Gool, L. (2014).** *Food-101 – Mining Discriminative Components with Random Forests.* European Conference on Computer Vision (ECCV).
2. **Ataguba, G., et al. (2024).** *Exploring Deep Learning–Based Models for Sociocultural African Food Recognition System.* Human-Computer Interaction & Data in Brief.
3. **Sandler, M., Howard, A., Zhu, M., Zhmoginov, A., & Chen, L. C. (2018).** *MobileNetV2: Inverted Residuals and Linear Bottlenecks.* IEEE Conference on Computer Vision and Pattern Recognition (CVPR).
4. **Vaswani, A., et al. (2017).** *Attention Is All You Need.* Advances in Neural Information Processing Systems (NeurIPS).

---

## 📜 Declaration & Acknowledgements

We declare that this project, titled **"AI-Powered Food Detection and Recipe Chatbot System"**, represents original undergraduate capstone work conducted within the **Department of Information Technology and Decision Sciences** at the **University of Energy and Natural Resources (UENR)**, Sunyani.

We extend our sincere gratitude to our project supervisor, **Dr. Anokye Acheampong Amponsah**, for his mentorship, technical guidance, and constructive critique throughout the design and realization of this system.

---

## 📄 License

This project is developed for academic and educational purposes under the Department of Information Technology and Decision Sciences, University of Energy and Natural Resources (UENR).
